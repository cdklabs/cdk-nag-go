import { CfnResource } from 'aws-cdk-lib';
import { IConstruct } from 'constructs';
import { NagPack, NagPackProps } from '../nag-pack';
/**
 * Check Best practices based on AWS Solutions Security Matrix
 *
 */
export declare class AwsSolutionsChecks extends NagPack {
    readonly name = "AwsSolutions";
    constructor(scope?: IConstruct, props?: NagPackProps);
    protected checkResource(node: CfnResource): void;
    /**
     * Check Compute Services
     * @param node the CfnResource to check
     */
    private checkCompute;
    /**
     * Check Storage Services
     * @param node the CfnResource to check
     */
    private checkStorage;
    /**
     * Check Database Services
     * @param node the CfnResource to check
     */
    private checkDatabases;
    /**
     * Check Network and Delivery Services
     * @param node the CfnResource to check
     */
    private checkNetworkDelivery;
    /**
     * Check Management and Governance Services
     * @param node the CfnResource to check
     */
    private checkManagementGovernance;
    /**
     * Check Machine Learning Services
     * @param node the CfnResource to check
     */
    private checkMachineLearning;
    /**
     * Check Analytics Services
     * @param node the CfnResource to check
     */
    private checkAnalytics;
    /**
     * Check Security and Compliance Services
     * @param node the CfnResource to check
     */
    private checkSecurityCompliance;
    /**
     * Check Serverless Services
     * @param node the CfnResource to check
     */
    private checkServerless;
    /**
     * Check Application Integration Services
     * @param node the CfnResource to check
     */
    private checkApplicationIntegration;
    /**
     * Check Media Services
     * @param node the CfnResource to check
     */
    private checkMediaServices;
    /**
     * Check Developer Tools Services
     * @param node the CfnResource to check
     */
    private checkDeveloperTools;
    /**
     * Check Lambda Services
     * @param node the CfnResource to check
     */
    private checkLambda;
}
