/**
 * Schema for the NagReport output.
 */
export interface NagReportSchema {
    readonly lines: NagReportLine[];
}
/**
 * A single line in a NagReport.
 */
export interface NagReportLine {
    readonly ruleId: string;
    readonly resourceId: string;
    readonly compliance: string;
    readonly ruleLevel: string;
    readonly ruleInfo: string;
}
/**
 * Possible output formats of the NagReport.
 */
export declare enum NagReportFormat {
    CSV = "csv",
    JSON = "json"
}
