import { CfnResource, IAspect, IPolicyValidationPlugin, IPolicyValidationContext, PolicyValidationPluginReport } from 'aws-cdk-lib';
import { IConstruct } from 'constructs';
import { NagMessageLevel, NagRuleResult } from './nag-rules';
/**
 * Extended validation context that includes the construct tree.
 * Requires CDK core change to populate `appConstruct` during plugin validation.
 */
export interface INagValidationContext extends IPolicyValidationContext {
    readonly appConstruct: IConstruct;
}
/**
 * Interface for creating a NagPack.
 */
export interface NagPackProps {
    /**
     * Whether or not to enable extended explanatory descriptions on warning, error, and logged ignore messages (default: false).
     */
    readonly verbose?: boolean;
    /**
     * Whether to write acknowledged rules into CfnResource CloudFormation
     * Metadata as `cdk_nag: { rules_to_suppress: [...] }` for backwards
     * compatibility with v2 audit trail tooling (default: false).
     */
    readonly writeSuppressionsToCloudFormation?: boolean;
}
/**
 * Interface for JSII interoperability for passing parameters and the Rule Callback to @applyRule method.
 */
export interface IApplyRule {
    /**
     * Override for the suffix of the Rule ID for this rule
     */
    ruleSuffixOverride?: string;
    /**
     * Why the rule was triggered.
     */
    info: string;
    /**
     * Why the rule exists.
     */
    explanation: string;
    /**
     * The annotations message level to apply to the rule if triggered.
     */
    level: NagMessageLevel;
    /**
     * The CfnResource to check
     */
    node: CfnResource;
    /**
     * The callback to the rule.
     * @param node The CfnResource to check.
     */
    rule(node: CfnResource): NagRuleResult;
}
/**
 * Base class for all rule packs. Implements IPolicyValidationPlugin so that
 * packs are registered via `Validations.of(app).addPlugins(new MyPack(app))`
 * instead of `Aspects.of(app).add(...)`.
 */
export declare abstract class NagPack implements IPolicyValidationPlugin {
    abstract readonly name: string;
    readonly version?: string;
    readonly ruleIds?: string[];
    protected packName: string;
    private violations;
    private verbose;
    constructor(scope?: IConstruct, props?: NagPackProps);
    get readPackName(): string;
    /**
     * Entry point called by the CDK validation framework.
     * Requires `appConstruct` to be present on the context (CDK core change).
     * For testing or direct invocation, use `validateScope(scope)`.
     */
    validate(context: IPolicyValidationContext): PolicyValidationPluginReport;
    /**
     * Validate a construct tree directly. This is the primary entry point
     * for testing and for CDK versions that do not yet provide `appConstruct` on
     * `IPolicyValidationContext`.
     */
    validateScope(scope: IConstruct): PolicyValidationPluginReport;
    /**
     * Recursively walk the construct tree and invoke checkResource on each CfnResource.
     */
    private walkTree;
    /**
     * Subclasses implement this to apply rules to each CfnResource.
     */
    protected abstract checkResource(node: CfnResource): void;
    /**
     * Create a rule to be used in the NagPack.
     * @param params The @IApplyRule interface with rule details.
     */
    protected applyRule(params: IApplyRule): void;
    /**
     * Add a violation to the internal violations array, grouping by ruleName.
     */
    private addViolation;
    /**
     * Check whether a specific rule has been acknowledged on the given resource
     * or any of its ancestor constructs via the CDK Validations
     * acknowledged-rules metadata mechanism.
     */
    private isAcknowledged;
}
/**
 * An IAspect that reads acknowledged rules from construct metadata and writes
 * them into the CfnResource's CloudFormation Metadata for audit trail
 * persistence in the synthesized template. Preserves the v2 `cdk_nag`
 * metadata format.
 */
export declare class WriteNagSuppressionsToCloudFormationAspect implements IAspect {
    visit(node: IConstruct): void;
}
