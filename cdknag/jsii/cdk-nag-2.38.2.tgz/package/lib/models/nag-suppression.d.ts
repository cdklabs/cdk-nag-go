/**
 * Interface for creating a rule suppression
 */
export interface NagPackSuppression {
    /**
     * The id of the rule to ignore
     */
    readonly id: string;
    /**
     * The reason to ignore the rule (minimum 10 characters)
     */
    readonly reason: string;
    /**
     * Rule specific granular suppressions
     */
    readonly appliesTo?: NagPackSuppressionAppliesTo[];
}
/**
 * A granular suppression
 */
export type NagPackSuppressionAppliesTo = string | RegexAppliesTo;
/**
 * A regular expression to apply to matching findings
 */
export interface RegexAppliesTo {
    /**
     * An ECMA-262 regex string
     */
    readonly regex: string;
}
